-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 08, 2018 at 11:04 AM
-- Server version: 5.6.38
-- PHP Version: 7.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `id` int(11) UNSIGNED NOT NULL,
  `img` varchar(32) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_delete` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`id`, `img`, `created_at`, `updated_at`, `is_delete`) VALUES
(1, 'brand/4.png', '2018-08-08 08:45:03', '2018-08-08 09:04:01', 0),
(2, 'brand/5.png', '2018-08-08 08:51:01', '2018-08-08 09:04:05', 0),
(3, 'brand/6.png', '2018-08-08 08:51:06', '2018-08-08 09:04:09', 0),
(4, 'brand/7.png', '2018-08-08 08:51:12', '2018-08-08 09:04:13', 0),
(5, 'brand/8.jpg', '2018-08-08 08:51:18', '2018-08-08 08:51:18', 0),
(6, 'brand/4.png', '2018-08-08 09:04:20', '2018-08-08 09:04:20', 0),
(7, 'brand/5.png', '2018-08-08 09:04:24', '2018-08-08 09:04:29', 0),
(8, 'brand/6.png', '2018-08-08 09:04:33', '2018-08-08 09:04:33', 0),
(9, 'brand/7.png', '2018-08-08 09:04:39', '2018-08-08 09:04:39', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brand`
--
ALTER TABLE `brand`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
