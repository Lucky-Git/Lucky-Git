-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 08, 2018 at 10:52 AM
-- Server version: 5.6.38
-- PHP Version: 7.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `id` int(11) UNSIGNED NOT NULL,
  `img` varchar(32) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_delete` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`id`, `img`, `created_at`, `updated_at`, `is_delete`) VALUES
(1, 'brand/4.jpg', '2018-08-08 08:45:03', '2018-08-08 08:50:57', 0),
(2, 'brand/5.jpg', '2018-08-08 08:51:01', '2018-08-08 08:51:01', 0),
(3, 'brand/6.jpg', '2018-08-08 08:51:06', '2018-08-08 08:51:06', 0),
(4, 'brand/7.jpg', '2018-08-08 08:51:12', '2018-08-08 08:51:12', 0),
(5, 'brand/8.jpg', '2018-08-08 08:51:18', '2018-08-08 08:51:18', 0);

-- --------------------------------------------------------

--
-- Table structure for table `carousel`
--

CREATE TABLE `carousel` (
  `id` int(11) UNSIGNED NOT NULL,
  `img` varchar(32) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_delete` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `carousel`
--

INSERT INTO `carousel` (`id`, `img`, `created_at`, `updated_at`, `is_delete`) VALUES
(2, 'carousel/1.jpg', '2018-08-06 04:01:43', '2018-08-06 04:01:43', 0),
(3, 'carousel/2.jpg', '2018-08-06 04:01:49', '2018-08-06 04:43:24', 0),
(4, 'carousel/3.jpg', '2018-08-06 04:01:52', '2018-08-06 04:43:27', 0),
(5, 'carousel/4.jpg', '2018-08-06 04:01:54', '2018-08-06 04:43:31', 0),
(6, 'carousel/5.jpg', '2018-08-06 04:01:57', '2018-08-06 04:43:34', 0);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '商品名称',
  `detial` varchar(255) NOT NULL DEFAULT '' COMMENT '商品描述',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '商品详情',
  `add_info` varchar(255) NOT NULL DEFAULT '' COMMENT '商品额外信息',
  `mainpic` varchar(255) NOT NULL DEFAULT '' COMMENT '商品图片',
  `pic1` varchar(255) NOT NULL DEFAULT '' COMMENT '商品图片1',
  `pic2` varchar(255) NOT NULL COMMENT '商品图片2',
  `pic3` varchar(255) NOT NULL DEFAULT '' COMMENT '商品图片3',
  `type` varchar(255) NOT NULL DEFAULT '' COMMENT '商品类别',
  `category` varchar(255) NOT NULL DEFAULT '' COMMENT '商品小类',
  `color` varchar(255) NOT NULL DEFAULT '' COMMENT '商品颜色',
  `size` varchar(255) NOT NULL DEFAULT '' COMMENT '商品尺码',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '商品价格',
  `discount` decimal(10,2) NOT NULL DEFAULT '1.00' COMMENT '商品打折',
  `endtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '商品打折截止时间',
  `count` int(11) NOT NULL DEFAULT '0' COMMENT '商品销售量',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间时间',
  `is_delete` tinyint(4) NOT NULL DEFAULT '0' COMMENT '删除状态'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL COMMENT 'ID',
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '用户名',
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT 'token',
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '密码',
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '重置密码token',
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '邮箱',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_delete` tinyint(4) NOT NULL DEFAULT '0' COMMENT '删除状态'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `created_at`, `updated_at`, `is_delete`) VALUES
(2, '123', '0gmTmGha8bE7BwFDaOsR8mJwqgAIVTW5', '$2y$13$KcX21fP0ONxjonnJhqoh1ODHFJmYrAqQtTcQrZ5j0.6vUJUH79WlO', NULL, 'j@q.com', '2018-07-28 06:48:43', '2018-07-28 07:02:36', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `carousel`
--
ALTER TABLE `carousel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brand`
--
ALTER TABLE `brand`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `carousel`
--
ALTER TABLE `carousel`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID', AUTO_INCREMENT=3;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
