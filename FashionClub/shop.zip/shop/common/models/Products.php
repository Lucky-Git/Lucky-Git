<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "products".
 *
 * @property int $id
 * @property string $name 商品名称
 * @property string $detial 商品描述
 * @property string $description 商品详情
 * @property string $add_info 商品额外信息
 * @property string $mainpic 商品图片
 * @property string $pic1 商品图片1
 * @property string $pic2 商品图片2
 * @property string $pic3 商品图片3
 * @property string $type 商品类别
 * @property string $category 商品小类
 * @property string $color 商品颜色
 * @property string $size 商品尺码
 * @property string $price 商品价格
 * @property string $discount 商品打折
 * @property string $endtime 商品打折截止时间
 * @property int $count 商品销售量
 * @property string $created_at 创建时间
 * @property string $updated_at 更新时间时间
 * @property int $is_delete 删除状态
 */
class Products extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'products';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['pic2'], 'required'],
            [['price', 'discount'], 'number'],
            [['endtime', 'created_at', 'updated_at'], 'safe'],
            [['count'], 'integer'],
            [['name', 'detial', 'description', 'add_info', 'mainpic', 'pic1', 'pic2', 'pic3', 'type', 'category', 'color', 'size'], 'string', 'max' => 255],
            [['is_delete'], 'string', 'max' => 4],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'detial' => 'Detial',
            'description' => 'Description',
            'add_info' => 'Add Info',
            'mainpic' => 'Mainpic',
            'pic1' => 'Pic1',
            'pic2' => 'Pic2',
            'pic3' => 'Pic3',
            'type' => 'Type',
            'category' => 'Category',
            'color' => 'Color',
            'size' => 'Size',
            'price' => 'Price',
            'discount' => 'Discount',
            'endtime' => 'Endtime',
            'count' => 'Count',
            'created_at' => 'Created At',
            'updated_at' => 'Updated At',
            'is_delete' => 'Is Delete',
        ];
    }
}
