<?php

namespace backend\controllers;

use Yii;
use yii\data\ArrayDataProvider;
use yii\filters\Cors;
use yii\helpers\ArrayHelper;
use yii\rest\ActiveController;

class CarouselController extends ActiveController {

	public $modelClass = 'common\models\Carousel';

	public function init() {
		parent::init();
		Yii::$app->user->enableSession = false;
	}

	public function behaviors() {
		return ArrayHelper::merge([
			[
				'class' => Cors::className(),
				'cors' => [
					'Origin' => ['*'],
					'Access-Control-Request-Method' => ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS'],
					'Access-Control-Request-Headers' => ['*'],
					'Access-Control-Expose-Headers' => ['x-pagination-total-count', 'x-pagination-page-count', 'x-pagination-current-page', 'x-pagination-per-page'],
				],
			],
		], parent::behaviors());
	}

	public function actions() {
		$actions = parent::actions();

		unset($actions['create'], $actions['delete'], $actions['update'], $actions['index'], $actions['view']);

		return $actions;
	}

	public function actionCreate() {
		return 0;
	}

	public function actionDelete() {
		return 0;
	}

	public function actionUpdate() {
		return 0;
	}

	public function actionIndex() {
		$query = (new \yii\db\Query())->select('*')
			->from('Carousel')
			->where(['is_delete' => 0])
			->orderBy('created_at DESC')
			->all();

		return new ArrayDataProvider([
			'pagination' => [
				'pageSize' => 10,
			],
			'allModels' => $query,
		]);
	}

	public function actionView() {
		return 0;
	}
}