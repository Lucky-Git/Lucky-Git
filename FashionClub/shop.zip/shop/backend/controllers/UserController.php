<?php

namespace backend\controllers;

use common\models\User;
use Yii;
use yii\data\ArrayDataProvider;
use yii\filters\Cors;
use yii\helpers\ArrayHelper;
use yii\rest\ActiveController;

class UserController extends ActiveController {

	public $modelClass = 'common\models\User';

	public function init() {
		parent::init();
		Yii::$app->user->enableSession = false;
	}

	public function behaviors() {
		return ArrayHelper::merge([
			[
				'class' => Cors::className(),
				'cors' => [
					'Origin' => ['*'],
					'Access-Control-Request-Method' => ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS'],
					'Access-Control-Request-Headers' => ['*'],
					'Access-Control-Expose-Headers' => ['x-pagination-total-count', 'x-pagination-page-count', 'x-pagination-current-page', 'x-pagination-per-page'],
				],
			],
		], parent::behaviors());
	}

	public function actions() {
		$actions = parent::actions();

		unset($actions['create'], $actions['delete'], $actions['update'], $actions['index'], $actions['view']);

		return $actions;
	}

	public function actionCreate() {
		$username = Yii::$app->request->post('username');
		$email = Yii::$app->request->post('email');
		$password = Yii::$app->request->post('password');
		$password_hash = Yii::$app->getSecurity()->generatePasswordHash($password);

		$query = (new \yii\db\Query())
			->select('*')->from('user')
			->where(['username' => $username, 'is_delete' => 0])
			->orWhere(['email' => $email, 'is_delete' => 0])
			->all();

		if (empty($query)) {
			$user = new User();
			$user->username = $username;
			$user->email = $email;
			$user->password_hash = $password_hash;
			$user->save();

			$response = Yii::$app->response;
			$response->statusCode = 201;
			$response->format = \yii\web\Response::FORMAT_JSON;
			$response->data = [
				'name' => "成功创建一个资源",
				'message' => '',
				'code' => 0,
				'status' => 201,
			];
			return $response;
		} else {
			throw new \yii\web\HttpException(400);
		}
	}

	public function actionLogin() {
		$account = Yii::$app->request->post('account');
		$password = Yii::$app->request->post('password');

		$user = (new \yii\db\Query())
			->select(['id', 'username', 'email'])
			->from('user')
			->where(['username' => $account, 'is_delete' => 0])
			->orWhere(['email' => $account, 'is_delete' => 0])
			->one();

		$password_hash = (new \yii\db\Query())
			->select(['password_hash'])
			->from('user')
			->where(['username' => $account, 'is_delete' => 0])
			->orWhere(['email' => $account, 'is_delete' => 0])
			->one();

		if (empty($user) || !Yii::$app->getSecurity()->validatePassword($password, $password_hash['password_hash'])) {
			throw new \yii\web\HttpException(401);
		}

		$the_user = User::find()
			->where(['username' => $account, 'is_delete' => 0])
			->orWhere(['email' => $account, 'is_delete' => 0])
			->one();
		$access_token = Yii::$app->security->generateRandomString();
		$the_user->auth_key = $access_token;
		$the_user->save(false);

		$response = Yii::$app->response;
		$response->format = \yii\web\Response::FORMAT_JSON;
		$response->data = [
			'name' => "一切正常",
			'message' => $user,
			'code' => 0,
			'status' => 200,
			'access_token' => $access_token,
		];
		return $response;
	}

	public function actionDelete() {
		// $id = Yii::$app->request->get('id');

		// $shop = Shop::find()
		// 	->where(['id' => $id, 'is_delete' => 0])
		// 	->one();

		// if (empty($shop)) {
		// 	throw new \yii\web\HttpException(400);
		// }

		// $shop->is_delete = 1;
		// $shop->save(false);

		// $response = Yii::$app->response;
		// $response->statusCode = 204;
		// $response->format = \yii\web\Response::FORMAT_JSON;
		// $response->data = [
		// 	'name' => "该请求被成功处理",
		// 	'message' => '',
		// 	'code' => 0,
		// 	'status' => 204,
		// ];
		// return $response;
	}

	public function actionUpdate() {
		// $id = Yii::$app->request->get('id');

		// $shop = Shop::find()
		// 	->where(['id' => $id, 'is_delete' => 0])
		// 	->one();

		// if (empty($shop)) {
		// 	throw new \yii\web\HttpException(400);
		// }

		// $phone = Yii::$app->request->post('phone');
		// $name = Yii::$app->request->post('name');
		// $province = Yii::$app->request->post('province');
		// $city = Yii::$app->request->post('city');
		// $town = Yii::$app->request->post('town');
		// $belong = Yii::$app->request->post('belong');

		// $shop->phone = $phone;
		// $shop->name = $name;
		// $shop->province = $province;
		// $shop->city = $city;
		// $shop->town = $town;
		// $shop->belong = $belong;

		// $query = (new \yii\db\Query())
		// 	->select('*')->from('shop')
		// 	->where(['phone' => $phone, 'is_delete' => 0])
		// 	->andWhere(['!=', 'id', $id])
		// 	->one();

		// if (!empty($query)) {
		// 	$response = Yii::$app->response;
		// 	$response->format = \yii\web\Response::FORMAT_JSON;
		// 	$response->data = [
		// 		'name' => "错误的请求",
		// 		'message' => '手机号已存在',
		// 		'code' => 0,
		// 		'status' => 400,
		// 	];
		// 	return $response;
		// }

		// $shop->save(false);

		// $response = Yii::$app->response;
		// $response->statusCode = 204;
		// $response->format = \yii\web\Response::FORMAT_JSON;
		// $response->data = [
		// 	'name' => "该请求被成功处理",
		// 	'message' => '',
		// 	'code' => 0,
		// 	'status' => 204,
		// ];
		// return $response;
	}

	public function actionIndex() {
		$query = (new \yii\db\Query())->select('*')
			->from('user')
			->where(['is_delete' => 0])
			->orderBy('created_at DESC')
			->all();

		return new ArrayDataProvider([
			'pagination' => [
				'pageSize' => 10,
			],
			'allModels' => $query,
		]);
	}

	public function actionView() {
		// $id = Yii::$app->request->get('id');

		// $shop = Shop::find()
		// 	->where(['id' => $id, 'is_delete' => 0])
		// 	->one();

		// if (empty($shop)) {
		// 	throw new \yii\web\HttpException(400);
		// }

		// $response = Yii::$app->response;
		// $response->statusCode = 200;
		// $response->format = \yii\web\Response::FORMAT_JSON;
		// $response->data = [
		// 	'name' => "该请求被成功处理",
		// 	'message' => $shop,
		// 	'code' => 0,
		// 	'status' => 200,
		// ];
		// return $response;
	}
}